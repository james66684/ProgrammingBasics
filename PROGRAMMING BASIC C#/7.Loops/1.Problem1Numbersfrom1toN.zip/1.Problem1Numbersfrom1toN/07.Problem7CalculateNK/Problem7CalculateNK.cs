﻿using System;

    class Problem7CalculateNK
    {
        static void Main(string[] args)
        {
            
        }
    }
